package com.cloudy.injector;

public final class BuildConfig {
public static final boolean DEBUG = true;
public static final String APPLICATION_ID = "com.cloudy.injector";
public static final String BUILD_TYPE = "release";
public static final int VERSION_CODE = 31;
public static final String VERSION_NAME = "1.0.8";
}